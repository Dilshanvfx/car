export enum Tool {
  BRUSH = 'BRUSH',
  ERASER = 'ERASER',
}

export type LoadingProgress = {
  stage: string;
  progress: number;
};

export type ControlInputType = 'edge' | 'depth' | 'pose';

export type GenerationQuality = 'low' | 'medium' | 'high';

export type ModelStyle = 'photoreal' | 'cinematic' | 'painterly' | 'vectorized';

export type AIStylePreset = 'cinematic' | 'vintage' | 'futuristic' | 'monochrome';

export type MagicRelightOption = 'from-left' | 'from-right' | 'from-top' | 'frontal';

export type AIDepthBlurAmount = 'subtle' | 'medium' | 'strong';

export type OneClickAction = 
  | 'upscale' 
  | 'remove-bg' 
  | `style-${AIStylePreset}`
  | `relight-${MagicRelightOption}`
  | 'pose'
  | `blur-${AIDepthBlurAmount}`;
