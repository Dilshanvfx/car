import React, { useState, useCallback } from 'react';
import { Tool, GenerationQuality, AIStylePreset, MagicRelightOption, AIDepthBlurAmount, ControlInputType, OneClickAction } from './types';
import { generateInpaintedImage, generateFullImageEdit, upscaleImage, removeBackground, applyStylePreset, magicRelight, applyPoseTransfer, applyDepthBlur } from './services/geminiService';
import { PropertiesPanel } from './components/PropertiesPanel';
import { Canvas } from './components/Canvas';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ExportModal } from './components/ExportModal';
import { Icon } from './components/Icon';
import { HarmonyControls } from './components/HarmonyControls';


type ExportFormat = 'image/png' | 'image/jpeg' | 'image/webp';

interface ImageFileState {
  file: File;
  dataUrl: string;
}

const defaultLoadingMessage = {
    title: "AI is creating...",
    stages: ["Analyzing Mask", "Generating Draft", "Refining Result", "Harmonizing", "Finalizing"]
};

const promptTemplates = [
    "A majestic cat wearing a tiny crown, golden hour lighting",
    "Transform the landscape into a surreal, alien planet",
    "Add bioluminescent mushrooms glowing on the forest floor",
    "Render the scene in the style of a Studio Ghibli anime",
    "Add a reflection of a distant galaxy in the water",
    "A tiny spaceship landing in the background",
    "Cover the ground in a layer of morning mist"
];

const fileToBase64 = (file: File): Promise<{ b64: string; mime: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (!result.includes(',')) {
        return reject(new Error("Invalid data URL format."));
      }
      const b64 = result.split(',')[1];
      resolve({ b64, mime: file.type });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};


function App() {
  const [activeTool, setActiveTool] = useState<Tool>(Tool.BRUSH);
  const [brushSize, setBrushSize] = useState<number>(40);
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAccepting, setIsAccepting] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState(defaultLoadingMessage);
  const [loadingAction, setLoadingAction] = useState<OneClickAction | null>(null);

  const [originalImage, setOriginalImage] = useState<{
    element: HTMLImageElement;
    file: File;
  } | null>(null);
  
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [maskDataUrl, setMaskDataUrl] = useState<string>('');
  const [isFullImageGeneration, setIsFullImageGeneration] = useState<boolean>(false);

  const [quality, setQuality] = useState<GenerationQuality>('medium');
  
  const [warmth, setWarmth] = useState<number>(0);
  const [exposure, setExposure] = useState<number>(0);
  const [saturation, setSaturation] = useState<number>(0);

  const [controlInputs, setControlInputs] = useState<{ [key in ControlInputType]?: ImageFileState }>({});

  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handleImageUpload = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        setOriginalImage({ element: img, file });
        resetForNewImage();
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }, []);
  
  const readFileAsState = (file: File, setter: (state: ImageFileState | null) => void) => {
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setter({ file, dataUrl: reader.result as string });
        };
        reader.readAsDataURL(file);
      } else {
        setter(null);
      }
  };

  const handleControlInputChange = (type: ControlInputType, file: File | null) => {
    if (file) {
      readFileAsState(file, (state) => {
        setControlInputs(prev => ({...prev, [type]: state}));
      });
    } else {
      setControlInputs(prev => {
        const next = {...prev};
        delete next[type];
        return next;
      });
    }
  };


  const compositeCanvasToBlob = (format: ExportFormat = 'image/png'): Promise<Blob> => {
      return new Promise(async (resolve, reject) => {
          if (!originalImage) return reject(new Error("No original image to export."));

          const { element: baseImage } = originalImage;
          const canvas = document.createElement('canvas');
          canvas.width = baseImage.naturalWidth;
          canvas.height = baseImage.naturalHeight;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error("Could not get canvas context for exporting."));
          
          if (format !== 'image/png') {
              ctx.fillStyle = 'white';
              ctx.fillRect(0, 0, canvas.width, canvas.height);
          }

          const imageToDraw = (generatedImage && isFullImageGeneration) ? null : baseImage;
          if (imageToDraw) {
            ctx.drawImage(imageToDraw, 0, 0);
          }
          

          if (generatedImage) {
              const genImg = new Image();
              await new Promise<void>((res, rej) => {
                  genImg.onload = () => res();
                  genImg.onerror = rej;
                  genImg.src = generatedImage;
              });

              const offscreenCanvas = document.createElement('canvas');
              offscreenCanvas.width = canvas.width;
              offscreenCanvas.height = canvas.height;
              const offscreenCtx = offscreenCanvas.getContext('2d');
              if (!offscreenCtx) return reject(new Error("Could not create offscreen canvas for export."));

              // Apply harmony adjustments to the generated image
              offscreenCtx.filter = `brightness(${1 + exposure / 100}) saturate(${1 + saturation / 100})`;
              offscreenCtx.drawImage(genImg, 0, 0, canvas.width, canvas.height);
              offscreenCtx.filter = 'none';

              if (warmth !== 0) {
                  offscreenCtx.globalCompositeOperation = 'overlay';
                  offscreenCtx.fillStyle = warmth > 0 ? `rgba(255, 165, 0, ${warmth / 150})` : `rgba(0, 150, 255, ${Math.abs(warmth) / 150})`;
                  offscreenCtx.fillRect(0, 0, canvas.width, canvas.height);
                  offscreenCtx.globalCompositeOperation = 'source-over';
              }
              
              if (isFullImageGeneration) {
                  ctx.clearRect(0, 0, canvas.width, canvas.height);
                  if (format !== 'image/png') {
                    ctx.fillStyle = 'white';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                  }
                  ctx.drawImage(offscreenCanvas, 0, 0);
              } else if (maskDataUrl) {
                  const maskImg = new Image();
                  await new Promise<void>((res, rej) => {
                      maskImg.onload = () => res();
                      maskImg.onerror = rej;
                      maskImg.src = maskDataUrl;
                  });

                  offscreenCtx.globalCompositeOperation = 'destination-in';
                  offscreenCtx.drawImage(maskImg, 0, 0, canvas.width, canvas.height);
                  ctx.drawImage(offscreenCanvas, 0, 0);
              }
          }

          // Add watermark
          const fontSize = Math.max(12, Math.min(canvas.width / 60, canvas.height / 60));
          ctx.font = `bold ${fontSize.toFixed(0)}px "Inter", sans-serif`;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.textAlign = 'right';
          ctx.textBaseline = 'bottom';
          const margin = fontSize * 0.75;

          ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
          ctx.shadowBlur = 3;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 1;

          ctx.fillText('EDIDIL', canvas.width - margin, canvas.height - margin);
          ctx.shadowColor = 'transparent';


          canvas.toBlob(blob => {
              if (blob) resolve(blob);
              else reject(new Error("Failed to create blob from canvas."));
          }, format, format === 'image/jpeg' ? 0.9 : undefined);
      });
  };
  
  const handleGenerateWithMask = async () => {
    if (!originalImage || !prompt || !maskDataUrl) {
      alert("Please upload an image, draw a mask, and enter a prompt.");
      return;
    }

    setIsFullImageGeneration(false);
    setIsLoading(true);
    setLoadingMessage(defaultLoadingMessage);
    setGeneratedImage(null);

    try {
      const img = originalImage.element;
      const maskImg = new Image();
      
      const imageProcessingPromise = new Promise<string>((resolve, reject) => {
        maskImg.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error('Failed to create canvas context.'));
          
          ctx.drawImage(img, 0, 0);
          ctx.globalCompositeOperation = 'destination-out';
          ctx.drawImage(maskImg, 0, 0, img.naturalWidth, img.naturalHeight);
          
          const apiImageDataUrl = canvas.toDataURL('image/png');
          resolve(apiImageDataUrl.split(',')[1]);
        };
        maskImg.onerror = () => reject(new Error('Failed to load mask image.'));
        maskImg.src = maskDataUrl;
      });
      
      const base64ImageForApi = await imageProcessingPromise;
      
      const controlFiles = Object.values(controlInputs).map(ci => ci.file);
      const newImageBase64 = await generateInpaintedImage(base64ImageForApi, 'image/png', prompt, quality, controlFiles);
      setGeneratedImage(`data:image/png;base64,${newImageBase64}`);

    } catch (error) {
        console.error("Generation failed:", error);
        alert((error as Error).message);
    } finally {
        setIsLoading(false);
    }
  };

  const handleGenerateWithoutMask = async () => {
      if (!originalImage || !prompt) {
          alert("Please upload an image and enter a prompt.");
          return;
      }

      setIsFullImageGeneration(true);
      setIsLoading(true);
      setLoadingMessage({
          title: "AI is editing...",
          stages: ["Analyzing Image", "Generating Ideas", "Applying Edit", "Finalizing"]
      });
      setGeneratedImage(null);

      try {
          const { b64: base64ImageForApi, mime: mimeType } = await fileToBase64(originalImage.file);
          const newImageBase64 = await generateFullImageEdit(base64ImageForApi, mimeType, prompt, quality);
          setGeneratedImage(`data:image/png;base64,${newImageBase64}`);
      } catch (error) {
          console.error("Full image generation failed:", error);
          alert((error as Error).message);
      } finally {
          setIsLoading(false);
      }
  };
  
  const handleGenerate = () => {
    if (maskDataUrl) {
        handleGenerateWithMask();
    } else {
        handleGenerateWithoutMask();
    }
  }

  const handleExport = async (format: ExportFormat) => {
    if (!originalImage) return;
    setIsExporting(true);
    try {
        const blob = await compositeCanvasToBlob(format);
        const dataUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const fileExtension = format.split('/')[1];
        const originalName = originalImage.file.name.replace(/\.[^/.]+$/, "");
        link.download = `${originalName}-edidil-export.${fileExtension}`;
        link.href = dataUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(dataUrl);
    } catch(error) {
        console.error("Export failed:", error);
        alert("Sorry, the image could not be exported.");
    } finally {
      setIsExporting(false);
      setIsExportModalOpen(false);
    }
  };
  
  const handleFullImageOperation = async (
    operation: (base64: string, mime: string) => Promise<string>,
    actionId: OneClickAction,
    loadingMsg: { title: string, stages: string[] }
  ) => {
    if (!originalImage) return;

    setLoadingMessage(loadingMsg);
    setLoadingAction(actionId);
    
    try {
        const { b64: base64Image, mime: mimeType } = await fileToBase64(originalImage.file);
        
        const resultImageBase64 = await operation(base64Image, mimeType);
        
        const newImageDataUrl = `data:image/png;base64,${resultImageBase64}`;
        const img = new Image();
        img.onload = async () => {
            try {
                const resultBlob = await (await fetch(newImageDataUrl)).blob();
                const newFile = new File([resultBlob], `${actionId}_${originalImage.file.name}`, { type: 'image/png' });
                setOriginalImage({ element: img, file: newFile });
                resetForNewImage(); 
            } catch (innerError) {
                console.error("Full image operation post-processing failed:", innerError);
                alert((innerError as Error).message || "An error occurred while processing the new image.");
            } finally {
              setLoadingAction(null);
            }
        };
        img.onerror = () => {
            console.error("Failed to load new image from data URL after operation.");
            alert("The generated image could not be loaded.");
            setLoadingAction(null);
        };
        img.src = newImageDataUrl;

    } catch (error) {
        console.error("Full image operation failed:", error);
        alert((error as Error).message);
        setLoadingAction(null);
    }
  };

  const handleUpscale = () => {
    handleFullImageOperation(
        (b64, mime) => upscaleImage(b64, mime), 
        'upscale',
        { title: "AI is Upscaling...", stages: ["Compositing Image", "Sending to AI", "Enhancing Details", "Finalizing Result"] }
    );
  };

  const handleRemoveBackground = () => {
    handleFullImageOperation(
        (b64, mime) => removeBackground(b64, mime),
        'remove-bg',
        { title: "AI is Removing Background...", stages: ["Analyzing Subject", "Creating Mask", "Isolating Foreground", "Finalizing Image"] }
    );
  };
  
  const handleApplyStylePreset = (style: AIStylePreset) => {
    handleFullImageOperation(
        (b64, mime) => applyStylePreset(b64, mime, style),
        `style-${style}`,
        { title: `Applying ${style.charAt(0).toUpperCase() + style.slice(1)} Style...`, stages: ["Compositing Image", "Sending to AI", "Applying Style", "Finalizing Result"] }
    );
  };

  const handleMagicRelight = (direction: MagicRelightOption) => {
    handleFullImageOperation(
        (b64, mime) => magicRelight(b64, mime, direction),
        `relight-${direction}`,
        { title: `Applying Magic Relight...`, stages: ["Analyzing Scene", "Calculating Shadows", "Redrawing Highlights", "Finalizing Image"] }
    );
  };

  const handleApplyPose = () => {
    const poseReferenceFile = controlInputs.pose?.file;
    if (!poseReferenceFile) {
      alert("Please upload a pose reference image first.");
      return;
    }
    handleFullImageOperation(
        (b64, mime) => applyPoseTransfer(b64, mime, poseReferenceFile),
        'pose',
        { title: "AI is Applying Pose...", stages: ["Analyzing Pose", "Applying to Subject", "Blending Result", "Finalizing Image"] }
    );
  };

  const handleApplyDepthBlur = (amount: AIDepthBlurAmount) => {
    handleFullImageOperation(
        (b64, mime) => applyDepthBlur(b64, mime, amount),
        `blur-${amount}`,
        { title: `Applying ${amount} Depth Blur...`, stages: ["Analyzing Depth", "Isolating Subject", "Applying Blur", "Finalizing Image"] }
    );
  };

  const handleAccept = async () => {
    if (!originalImage || !generatedImage) return;
    setIsAccepting(true);
    try {
        const blob = await compositeCanvasToBlob('image/png');
        
        const newImageDataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });

        const img = new Image();
        await new Promise<void>((resolve, reject) => {
            img.onload = () => resolve();
            img.onerror = () => reject(new Error("Failed to load image from data URL."));
            img.src = newImageDataUrl;
        });
        
        const newFile = new File([blob], `edited_${originalImage.file.name}`, { type: 'image/png' });
        setOriginalImage({ element: img, file: newFile });
        resetForNewImage();

    } catch (error) {
        console.error("Failed to accept changes:", error);
        alert("Could not apply changes.");
    } finally {
        setIsAccepting(false);
    }
  }
  
  const handleCancel = () => {
      setGeneratedImage(null);
      setWarmth(0);
      setExposure(0);
      setSaturation(0);
  }

  const resetForNewImage = () => {
    setGeneratedImage(null);
    setMaskDataUrl('');
    setPrompt('');
    setQuality('medium');
    setWarmth(0);
    setExposure(0);
    setSaturation(0);
    setControlInputs({});
    setIsLoading(false);
    setLoadingAction(null);
    setIsFullImageGeneration(false);
  }

  const resetApp = () => {
      setOriginalImage(null);
      resetForNewImage();
  }
  
  const handlePromptIdeaClick = () => {
    const randomIdea = promptTemplates[Math.floor(Math.random() * promptTemplates.length)];
    setPrompt(prompt => prompt ? `${prompt}, ${randomIdea.toLowerCase()}` : randomIdea);
  }


  if (!originalImage) {
    return <WelcomeScreen onImageUpload={handleImageUpload} />;
  }
  
  const isGenerateDisabled = isLoading || loadingAction !== null || !originalImage || !prompt;
  const isMaskActive = !!maskDataUrl;


  return (
    <div className="w-screen h-screen flex flex-col antialiased overflow-hidden">
      <header className="w-full h-16 bg-slate-950/50 flex-shrink-0 flex items-center px-6 justify-between border-b border-white/10 backdrop-blur-xl z-10 animate-fadeIn" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center gap-3">
            <Icon icon="logo" className="text-slate-200 w-8 h-8" />
            <h1 className="text-slate-200 text-lg font-bold tracking-wider" style={{ textShadow: 'var(--shadow-text)' }}>EDIDIL</h1>
          </div>
          <button 
            onClick={resetApp}
            className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-200 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
        >
            <Icon icon="newProject" className="w-4 h-4" />
            New Project
        </button>
      </header>
      
      <div className="flex-grow flex p-4 sm:p-6 md:p-8 gap-8 overflow-hidden">
        <div className="flex-grow flex flex-col gap-4">
             <main className="flex-grow bg-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-white/10 animate-fadeIn" style={{ animationDelay: '0.2s' }}>
                <Canvas 
                  image={originalImage.element}
                  activeTool={activeTool}
                  brushSize={brushSize}
                  generatedImage={generatedImage}
                  onMaskReady={setMaskDataUrl}
                  isGenerating={isLoading || isAccepting || loadingAction !== null}
                  loadingMessage={loadingMessage}
                  warmth={warmth}
                  exposure={exposure}
                  saturation={saturation}
                  setActiveTool={setActiveTool}
                  setBrushSize={setBrushSize}
                  isFullImageGeneration={isFullImageGeneration}
                />
            </main>
            {generatedImage ? (
                <HarmonyControls 
                    warmth={warmth}
                    setWarmth={setWarmth}
                    exposure={exposure}
                    setExposure={setExposure}
                    saturation={saturation}
                    setSaturation={setSaturation}
                    onAccept={handleAccept}
                    onCancel={handleCancel}
                    isAccepting={isAccepting}
                />
            ) : (
                <div className="command-bar flex-shrink-0 h-28 flex gap-4 p-4 card-style">
                    <div className="relative flex-grow">
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Describe your edit..."
                            className="w-full h-full p-4 pr-12 sub-card-style text-slate-100 text-lg font-medium rounded-2xl resize-none focus:ring-2 focus:ring-pink-500/80 focus:outline-none placeholder:text-slate-400"
                            disabled={isLoading || loadingAction !== null}
                        />
                        <button 
                            onClick={handlePromptIdeaClick}
                            disabled={isLoading || loadingAction !== null}
                            className="absolute top-1/2 right-4 -translate-y-1/2 text-slate-400 hover:text-pink-400 transition-colors disabled:opacity-40"
                            aria-label="Get prompt ideas"
                        >
                            <Icon icon="sparkles" className="w-6 h-6" />
                        </button>
                    </div>
                    
                    <button 
                        onClick={handleGenerate}
                        disabled={isGenerateDisabled}
                        className="w-28 h-full gradient-button text-white font-bold rounded-2xl flex flex-col items-center justify-center gap-1 text-sm"
                    >
                        <Icon icon={isMaskActive ? 'brush' : 'frame'} className="w-7 h-7" />
                        <span>{isMaskActive ? 'Inpaint' : 'Generate'}</span>
                    </button>
                </div>
            )}
        </div>

        <PropertiesPanel
            onUpscale={handleUpscale}
            onRemoveBackground={handleRemoveBackground}
            onApplyStylePreset={handleApplyStylePreset}
            onMagicRelight={handleMagicRelight}
            onApplyPose={handleApplyPose}
            onApplyDepthBlur={handleApplyDepthBlur}
            isLoading={isLoading || !!generatedImage}
            hasOriginalImage={!!originalImage}
            quality={quality}
            setQuality={setQuality}
            onExportClick={() => setIsExportModalOpen(true)}
            onControlInputChange={handleControlInputChange}
            controlInputs={controlInputs}
            loadingAction={loadingAction}
        />
      </div>

      <ExportModal 
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        onExport={handleExport}
        isExporting={isExporting}
      />
    </div>
  );
}

export default App;