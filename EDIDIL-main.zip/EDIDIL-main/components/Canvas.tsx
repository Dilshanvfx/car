import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Tool } from '../types';
import { Loader } from './Loader';
import { BrushControls } from './BrushControls';

interface CanvasProps {
  image: HTMLImageElement | null;
  activeTool: Tool;
  brushSize: number;
  generatedImage: string | null;
  onMaskReady: (maskDataUrl: string) => void;
  isGenerating: boolean;
  loadingMessage: { title: string, stages: string[] };
  warmth: number;
  exposure: number;
  saturation: number;
  setActiveTool: (tool: Tool) => void;
  setBrushSize: (size: number) => void;
  isFullImageGeneration: boolean;
}

export const Canvas: React.FC<CanvasProps> = ({ 
    image, activeTool, brushSize, generatedImage, onMaskReady, isGenerating, loadingMessage,
    warmth, exposure, saturation, setActiveTool, setBrushSize, isFullImageGeneration
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageCanvasRef = useRef<HTMLCanvasElement>(null); // For the original image ("before")
  const drawingCanvasRef = useRef<HTMLCanvasElement>(null); // For user's mask drawing
  const afterCanvasRef = useRef<HTMLCanvasElement>(null); // For the final composited image ("after")

  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [loadedGeneratedImage, setLoadedGeneratedImage] = useState<HTMLImageElement | null>(null);

  // State for the comparison slider
  const [sliderPosition, setSliderPosition] = useState(50); // 0-100 percentage
  const [isSliding, setIsSliding] = useState(false);

  const getCoords = useCallback((e: MouseEvent | TouchEvent) => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  }, []);

  const draw = useCallback((e: MouseEvent | TouchEvent) => {
    if (!isDrawing) return;
    const coords = getCoords(e);
    if (!coords) return;

    const ctx = drawingCanvasRef.current?.getContext('2d');
    if (!ctx) return;

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (activeTool === Tool.BRUSH) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = 'rgba(0, 0, 0, 1)'; 
    } else { // ERASER
      ctx.globalCompositeOperation = 'destination-out';
    }

    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
  }, [isDrawing, getCoords, brushSize, activeTool]);
  
  const startDrawing = useCallback((e: MouseEvent | TouchEvent) => {
    e.preventDefault();
    const coords = getCoords(e);
    if (!coords) return;
    setIsDrawing(true);
    const ctx = drawingCanvasRef.current?.getContext('2d');
    if (!ctx) return;
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
  }, [getCoords]);

  const stopDrawing = useCallback(() => {
    if (!isDrawing) return;
    const canvas = drawingCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.closePath();
    setIsDrawing(false);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    let hasDrawing = false;
    for (let i = 3; i < imageData.data.length; i += 4) {
      if (imageData.data[i] > 0) {
        hasDrawing = true;
        break;
      }
    }
    
    onMaskReady(hasDrawing ? canvas.toDataURL() : '');
  }, [isDrawing, onMaskReady]);

  const handleSliderMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsSliding(true);
  };

  const handleSliderMouseMove = useCallback((e: MouseEvent) => {
    if (!isSliding || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = canvasSize.width;
    let newPosition = (x / width) * 100;
    if (newPosition < 0) newPosition = 0;
    if (newPosition > 100) newPosition = 100;
    setSliderPosition(newPosition);
  }, [isSliding, canvasSize.width]);
  
  const handleSliderMouseUp = useCallback(() => {
    setIsSliding(false);
  }, []);

  useEffect(() => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return;
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing, { passive: false });
    canvas.addEventListener('touchmove', draw, { passive: false });
    canvas.addEventListener('touchend', stopDrawing);
    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseleave', stopDrawing);
      canvas.removeEventListener('touchstart', startDrawing);
      canvas.removeEventListener('touchmove', draw);
      canvas.removeEventListener('touchend', stopDrawing);
    };
  }, [startDrawing, draw, stopDrawing]);

  useEffect(() => {
    window.addEventListener('mousemove', handleSliderMouseMove);
    window.addEventListener('mouseup', handleSliderMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleSliderMouseMove);
      window.removeEventListener('mouseup', handleSliderMouseUp);
    };
  }, [handleSliderMouseMove, handleSliderMouseUp]);

  useEffect(() => {
    const resizeObserver = new ResizeObserver(entries => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      if (image) {
        const imageAspectRatio = image.width / image.height;
        const containerAspectRatio = width / height;
        let newWidth, newHeight;
        if (imageAspectRatio > containerAspectRatio) {
          newWidth = width;
          newHeight = width / imageAspectRatio;
        } else {
          newHeight = height;
          newWidth = height * imageAspectRatio;
        }
        setCanvasSize({ width: newWidth, height: newHeight });
      } else {
        setCanvasSize({ width, height });
      }
    });
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }
    return () => resizeObserver.disconnect();
  }, [image]);

  useEffect(() => {
    if (generatedImage) {
      const img = new Image();
      img.onload = () => {
        setLoadedGeneratedImage(img);
        setSliderPosition(50);
      };
      img.src = generatedImage;
    } else {
      setLoadedGeneratedImage(null);
    }
  }, [generatedImage]);

  useEffect(() => {
    if (!image || !canvasSize.width || !canvasSize.height) return;
    [imageCanvasRef, drawingCanvasRef, afterCanvasRef].forEach(ref => {
      const canvas = ref.current;
      if (canvas) {
        canvas.width = canvasSize.width;
        canvas.height = canvasSize.height;
      }
    });
    const imageCtx = imageCanvasRef.current?.getContext('2d');
    const drawingCtx = drawingCanvasRef.current?.getContext('2d');
    const afterCtx = afterCanvasRef.current?.getContext('2d');
    if (imageCtx) {
      imageCtx.clearRect(0,0, canvasSize.width, canvasSize.height);
      imageCtx.drawImage(image, 0, 0, canvasSize.width, canvasSize.height);
    }
    // Only clear the drawing canvas if there isn't a generated image being displayed.
    // This preserves the mask for the slider comparison view after generation.
    if (drawingCtx && !generatedImage) {
        drawingCtx.clearRect(0, 0, canvasSize.width, canvasSize.height);
    }
    if (afterCtx) afterCtx.clearRect(0, 0, canvasSize.width, canvasSize.height);
  }, [image, canvasSize, generatedImage]);

  useEffect(() => {
    if (!canvasSize.width || !imageCanvasRef.current || !afterCanvasRef.current || !drawingCanvasRef.current) return;
    
    const afterCtx = afterCanvasRef.current.getContext('2d');
    const maskCanvas = drawingCanvasRef.current;
    if (!afterCtx) return;

    afterCtx.clearRect(0, 0, canvasSize.width, canvasSize.height);
    if (!loadedGeneratedImage) return;

    const offscreenCanvas = new OffscreenCanvas(canvasSize.width, canvasSize.height);
    const offscreenCtx = offscreenCanvas.getContext('2d');
    if (!offscreenCtx) return;

    offscreenCtx.filter = `brightness(${1 + exposure / 100}) saturate(${1 + saturation / 100})`;
    offscreenCtx.drawImage(loadedGeneratedImage, 0, 0, canvasSize.width, canvasSize.height);
    offscreenCtx.filter = 'none';

    if (warmth !== 0) {
        offscreenCtx.globalCompositeOperation = 'overlay';
        offscreenCtx.fillStyle = warmth > 0 ? `rgba(255, 165, 0, ${warmth / 150})` : `rgba(0, 150, 255, ${Math.abs(warmth) / 150})`;
        offscreenCtx.fillRect(0, 0, canvasSize.width, canvasSize.height);
    }
    
    if (isFullImageGeneration) {
      afterCtx.drawImage(offscreenCanvas, 0, 0);
    } else {
      afterCtx.drawImage(imageCanvasRef.current, 0, 0, canvasSize.width, canvasSize.height);
      offscreenCtx.globalCompositeOperation = 'destination-in';
      offscreenCtx.drawImage(maskCanvas, 0, 0, canvasSize.width, canvasSize.height);
      afterCtx.drawImage(offscreenCanvas, 0, 0);
    }
  }, [loadedGeneratedImage, canvasSize, warmth, exposure, saturation, image, isFullImageGeneration]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex items-center justify-center relative"
      style={{
        backgroundColor: '#111827',
        backgroundImage: 'linear-gradient(45deg, #1f2937 25%, transparent 25%), linear-gradient(-45deg, #1f2937 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1f2937 75%), linear-gradient(-45deg, transparent 75%, #1f2937 75%)',
        backgroundSize: '24px 24px',
        backgroundPosition: '0 0, 0 12px, 12px -12px, -12px 0px',
      }}
    >
      <div className="relative" style={{ width: canvasSize.width, height: canvasSize.height, cursor: isSliding ? 'ew-resize' : 'default' }}>
        
        {!generatedImage && (
            <BrushControls 
                activeTool={activeTool} 
                setActiveTool={setActiveTool}
                brushSize={brushSize}
                setBrushSize={setBrushSize}
            />
        )}

        <canvas ref={imageCanvasRef} className="absolute top-0 left-0" />
        
        {generatedImage && (
            <canvas 
                ref={afterCanvasRef} 
                className="absolute top-0 left-0"
                style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
            />
        )}
        
        <canvas ref={drawingCanvasRef} className={`absolute top-0 left-0 ${generatedImage ? 'opacity-0 pointer-events-none' : 'opacity-50'} cursor-crosshair`} />
        
        {generatedImage && (
            <div 
                className="absolute top-0 bottom-0 w-1 bg-gradient-to-b from-pink-500 to-purple-500 shadow-lg cursor-ew-resize z-10 group"
                style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
                onMouseDown={handleSliderMouseDown}
            >
                <div className="absolute top-1/2 -translate-y-1/2 -left-[19px] w-10 h-10 rounded-full bg-slate-900/50 backdrop-blur-sm shadow-xl border-2 border-white/20 flex items-center justify-center text-white transition-transform duration-200 group-hover:scale-110">
                   <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 animate-pulse"></div>
                </div>
            </div>
        )}
        
        {isGenerating && <Loader title={loadingMessage.title} stages={loadingMessage.stages} />}
      </div>
    </div>
  );
};