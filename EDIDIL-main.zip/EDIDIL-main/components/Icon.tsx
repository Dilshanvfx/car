
import React from 'react';

interface IconProps {
  icon: 'brush' | 'eraser' | 'upload' | 'logo' | 'export' | 'close' | 'upscale' | 'removeBg' | 'film' | 'camera' | 'zap' | 'sun' | 'pose' | 'blur' | 'edges' | 'depth' | 'sparkles' | 'newProject' | 'frame' | 'spinner';
  className?: string;
}

const ICONS = {
  logo: (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20Z" fillOpacity="0.3"/>
        <path d="M12 4C11.1373 4 10.3341 4.31607 9.75 4.83398L14.166 9.25C14.6839 8.66588 15 7.86274 15 7C15 5.34315 13.6569 4 12 4Z"/>
        <path d="M4.83398 9.75C4.31607 10.3341 4 11.1373 4 12C4 13.6569 5.34315 15 7 15C7.86274 15 8.66588 14.6839 9.25 14.166L4.83398 9.75Z"/>
        <path d="M19.166 14.25C19.6839 13.6659 20 12.8627 20 12C20 10.3431 18.6569 9 17 9C16.1373 9 15.3341 9.31607 14.75 9.83398L19.166 14.25Z"/>
    </svg>
  ),
  brush: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9.06 11.9 3.42 17.53a2.83 2.83 0 0 0 4 4L13.1 15.9" />
      <path d="M16.59 3.59a2.12 2.12 0 0 1 3 3L7.83 18.34a2.12 2.12 0 0 1-3-3L16.59 3.59z" />
    </svg>
  ),
  eraser: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21H7Z" />
      <path d="M22 11.5 12.5 2" />
      <path d="m15 5 5 5" />
    </svg>
  ),
  upload: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" x2="12" y1="3" y2="15" />
    </svg>
  ),
  export: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" y2="3"></line>
    </svg>
  ),
  close: (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  ),
  upscale: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 21l-6-6m3-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
        <path d="M9 12h6"/>
        <path d="M12 9v6"/>
    </svg>
  ),
  removeBg: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12.5 2.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z"/>
        <path d="M12.5 10.13V5.5a2.5 2.5 0 0 0-5 0v1.63"/>
        <path d="M9.83 11.52A3.5 3.5 0 0 0 7.5 14.5V16"/>
        <path d="M12.5 16v-1.5a3.5 3.5 0 0 0-2.33-3.23"/>
        <path d="M12.5 16h-5a2.5 2.5 0 0 0-2.5 2.5V20a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1v-1.5a2.5 2.5 0 0 0-2.5-2.5Z"/>
        <path d="M18 10a4 4 0 0 0-4-4"/>
        <path d="M18 10h.5a2.5 2.5 0 0 1 2.5 2.5V14"/>
        <path d="M14 10h.5a2.5 2.5 0 0 0 2.5-2.5V6"/>
    </svg>
  ),
  film: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/>
        <line x1="7" y1="2" x2="7" y2="22"/>
        <line x1="17" y1="2" x2="17" y2="22"/>
        <line x1="2" y1="12" x2="22" y2="12"/>
        <line x1="2" y1="7" x2="7" y2="7"/>
        <line x1="2" y1="17" x2="7" y2="17"/>
        <line x1="17" y1="17" x2="22" y2="17"/>
        <line x1="17" y1="7" x2="22" y2="7"/>
    </svg>
  ),
  camera: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="12" rx="2" ry="2"/>
        <circle cx="12" cy="13" r="3"/>
        <path d="m18 7-3-3H9L6 7"/>
    </svg>
  ),
  zap: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  ),
  sun: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="4"/>
        <path d="M12 2v2"/>
        <path d="M12 20v2"/>
        <path d="m4.93 4.93 1.41 1.41"/>
        <path d="m17.66 17.66 1.41 1.41"/>
        <path d="M2 12h2"/>
        <path d="M20 12h2"/>
        <path d="m4.93 19.07 1.41-1.41"/>
        <path d="m17.66 6.34 1.41-1.41"/>
    </svg>
  ),
  pose: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="5" r="3"></circle>
        <path d="M12 8v7"></path>
        <path d="M5.5 15h13"></path>
        <path d="M12 15v7"></path>
        <path d="m8.5 22 3.5-4 3.5 4"></path>
    </svg>
  ),
  blur: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C3 11.1 2 13 2 15a7 7 0 0 0 7 7z"/>
    </svg>
  ),
  edges: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3v18h18"/>
      <path d="M3 8.5h15"/>
      <path d="M3 15.5h15"/>
      <path d="M8.5 3v15"/>
      <path d="M15.5 3v15"/>
    </svg>
  ),
  depth: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 2 7 12 12 22 7 12 2"/>
      <polyline points="2 17 12 22 22 17"/>
      <polyline points="2 12 12 17 22 12"/>
    </svg>
  ),
  sparkles: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m12 3-1.5 3L7 7.5l3 1.5L12 12l1.5-3L17 7.5l-3-1.5z"/>
      <path d="M5 11.5 3 13l1.5 1.5L6 16l1.5-1.5L9 13l-1.5-1.5z"/>
      <path d="M19 11.5 17 13l1.5 1.5L20 16l1.5-1.5L23 13l-1.5-1.5z"/>
    </svg>
  ),
  newProject: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
      <polyline points="14 2 14 8 20 8"/>
      <line x1="12" x2="12" y1="18" y2="12"/>
      <line x1="9" x2="15" y1="15" y2="15"/>
    </svg>
  ),
  frame: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
    </svg>
  ),
  spinner: (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </svg>
  )
};

export const Icon: React.FC<IconProps> = ({ icon, className }) => {
  return <div className={className}>{ICONS[icon]}</div>;
};