import React, { useMemo } from 'react';

interface HarmonyControlsProps {
  warmth: number;
  setWarmth: (value: number) => void;
  exposure: number;
  setExposure: (value: number) => void;
  saturation: number;
  setSaturation: (value: number) => void;
  onAccept: () => void;
  onCancel: () => void;
  isAccepting: boolean;
}

const Slider: React.FC<{ 
    label: string, 
    value: number, 
    onChange: (v: number) => void, 
    min?: number, 
    max?: number, 
    step?: number,
    gradient: string
}> = ({ label, value, onChange, min = -50, max = 50, step = 1, gradient }) => {
    const fillPercent = useMemo(() => {
        const range = max - min;
        const normalizedValue = value - min;
        return (normalizedValue / range) * 100;
    }, [value, min, max]);

    const sliderStyle = useMemo(() => ({
        '--track-fill': `${fillPercent}%`,
        '--track-bg': gradient,
    }), [fillPercent, gradient]);

    return (
        <div className="flex flex-col gap-2 flex-1">
            <div className="flex justify-between items-center px-1">
                <label className="text-sm font-medium text-slate-300" style={{ textShadow: 'var(--shadow-text)' }}>{label}</label>
                <span className="text-xs font-mono bg-slate-900/50 px-2 py-0.5 rounded border border-white/10">{value}</span>
            </div>
            <input
                type="range"
                min={min}
                max={max}
                step={step}
                value={value}
                onChange={(e) => onChange(Number(e.target.value))}
                className="w-full custom-slider"
                // FIX: Cast style object to React.CSSProperties to allow for custom CSS variables.
                style={sliderStyle as React.CSSProperties}
            />
        </div>
    );
};


export const HarmonyControls: React.FC<HarmonyControlsProps> = ({
    warmth, setWarmth, exposure, setExposure, saturation, setSaturation,
    onAccept, onCancel, isAccepting
}) => {
  return (
    <div className="animate-slideInUp flex-shrink-0 h-28 flex gap-4 p-4 card-style text-white">
        <div className="flex-grow flex items-center gap-6">
            <Slider label="Warmth" value={warmth} onChange={setWarmth} gradient="linear-gradient(90deg, #60a5fa, #fcd34d)" />
            <Slider label="Exposure" value={exposure} onChange={setExposure} gradient="linear-gradient(90deg, #a78bfa, #fde047)" />
            <Slider label="Saturation" value={saturation} onChange={setSaturation} gradient="linear-gradient(90deg, #9ca3af, #f472b6)" />
        </div>
        <div className="flex items-center gap-3">
            <button
                onClick={onCancel}
                disabled={isAccepting}
                className="w-28 h-full bg-slate-700/80 text-white font-bold rounded-xl hover:bg-slate-600/80 disabled:opacity-50 transition-all duration-200 border border-white/10"
            >
                Cancel
            </button>
             <button
                onClick={onAccept}
                disabled={isAccepting}
                className="w-28 h-full gradient-button text-white font-bold rounded-xl"
            >
                {isAccepting ? 'Applying...' : 'Accept'}
            </button>
        </div>
    </div>
  );
};