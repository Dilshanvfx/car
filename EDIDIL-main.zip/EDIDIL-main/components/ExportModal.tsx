import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';

type ExportFormat = 'image/png' | 'image/jpeg' | 'image/webp';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: (format: ExportFormat) => void;
  isExporting: boolean;
}

const FormatButton: React.FC<{
  label: string;
  format: ExportFormat;
  selectedFormat: ExportFormat;
  onClick: (format: ExportFormat) => void;
}> = ({ label, format, selectedFormat, onClick }) => (
  <button
    onClick={() => onClick(format)}
    className={`px-4 py-2 rounded-lg transition-colors w-full text-center font-semibold ${
      selectedFormat === format
        ? 'bg-pink-600 text-white shadow-md shadow-pink-500/20'
        : 'bg-slate-700/70 text-slate-200 hover:bg-slate-600/70'
    }`}
  >
    {label}
  </button>
);

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, onExport, isExporting }) => {
  const [format, setFormat] = useState<ExportFormat>('image/png');
  const [isShowing, setIsShowing] = useState(false);

  useEffect(() => {
      if (isOpen) {
          setIsShowing(true);
      } else {
          setIsShowing(false);
      }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleExport = () => {
    onExport(format);
  };

  return (
    <div 
        className={`absolute inset-0 flex items-center justify-center z-50 transition-opacity duration-300 ${isShowing ? 'opacity-100' : 'opacity-0'}`}
        onClick={onClose}
    >
      <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${isShowing ? 'opacity-100' : 'opacity-0'}`}></div>
      <div 
        className={`card-style p-8 w-full max-w-md shadow-2xl transition-all duration-300 ${isShowing ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-slate-100">Export Image</h2>
            <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 text-slate-400 hover:text-white">
                <Icon icon="close" className="w-4 h-4" />
            </button>
        </div>
        <p className="text-slate-400 mb-6">Choose your desired format to download the image.</p>
        
        <div className="mb-8">
          <label className="text-sm font-medium text-slate-300 mb-2 block">Format</label>
          <div className="grid grid-cols-3 items-center gap-2 bg-slate-900/50 p-1 rounded-xl">
            <FormatButton label="PNG" format="image/png" selectedFormat={format} onClick={setFormat} />
            <FormatButton label="JPG" format="image/jpeg" selectedFormat={format} onClick={setFormat} />
            <FormatButton label="WebP" format="image/webp" selectedFormat={format} onClick={setFormat} />
          </div>
        </div>
        
        <div className="flex justify-end gap-4">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-slate-700 text-slate-200 font-semibold rounded-lg hover:bg-slate-600 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-6 py-2 gradient-button text-white font-semibold rounded-lg flex items-center gap-2"
          >
            {isExporting && <Icon icon="spinner" className="w-4 h-4 animate-spin"/>}
            {isExporting ? 'Exporting...' : 'Download'}
          </button>
        </div>
      </div>
    </div>
  );
};