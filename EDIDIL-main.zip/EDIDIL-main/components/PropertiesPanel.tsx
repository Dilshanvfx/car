import React, { useRef } from 'react';
import { ControlInputType, GenerationQuality, AIStylePreset, MagicRelightOption, AIDepthBlurAmount, OneClickAction } from '../types';
import { Icon } from './Icon';

interface PropertiesPanelProps {
  onUpscale: () => void;
  onRemoveBackground: () => void;
  onApplyStylePreset: (style: AIStylePreset) => void;
  onMagicRelight: (direction: MagicRelightOption) => void;
  isLoading: boolean;
  hasOriginalImage: boolean;
  quality: GenerationQuality;
  setQuality: (quality: GenerationQuality) => void;
  onApplyPose: () => void;
  onApplyDepthBlur: (amount: AIDepthBlurAmount) => void;
  onExportClick: () => void;
  onControlInputChange: (type: ControlInputType, file: File | null) => void;
  controlInputs: { [key in ControlInputType]?: { file: File; dataUrl: string } };
  loadingAction: OneClickAction | null;
}

const PanelCard: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => (
    <div className={`card-style p-4 ${className}`} style={{ transform: 'translateY(0)', transition: 'transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease' }}>
        {children}
    </div>
);

const ChildButton: React.FC<{
    onClick?: () => void;
    disabled: boolean;
    isLoading: boolean;
    children: React.ReactNode;
    className?: string;
}> = ({ onClick, disabled, isLoading, children, className = '' }) => (
    <button
        onClick={onClick}
        disabled={disabled || isLoading}
        className={`w-full h-12 bg-slate-800/50 text-slate-200 font-semibold rounded-lg transition-all duration-200 border border-transparent
        hover:bg-slate-700/70 hover:border-slate-500/50 hover:shadow-lg hover:shadow-pink-500/10 hover:-translate-y-0.5
        active:translate-y-0 active:scale-[0.98] active:bg-slate-700/90
        disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none disabled:bg-slate-800/50 flex items-center justify-center ${className}`}
    >
        {isLoading ? <Icon icon="spinner" className="w-5 h-5 animate-spin text-pink-400" /> : <span style={{ textShadow: 'var(--shadow-text)' }}>{children}</span>}
    </button>
);

const ControlInput: React.FC<{
    type: ControlInputType;
    icon: 'edges' | 'depth' | 'pose';
    label: string;
    data: { dataUrl: string } | null;
    onChange: (file: File | null) => void;
    disabled: boolean;
}> = ({ type, icon, label, data, onChange, disabled }) => {
    const inputRef = useRef<HTMLInputElement>(null);
    return (
        <div className="sub-card-style p-2 flex items-center gap-3">
            <Icon icon={icon} className="w-6 h-6 flex-shrink-0 text-slate-400" />
            <span className="font-semibold text-sm flex-grow text-slate-200" style={{ textShadow: 'var(--shadow-text)' }}>{label}</span>
            {data ? (
                <div className="relative w-10 h-10 rounded-md bg-slate-700 ring-1 ring-white/10">
                    <img src={data.dataUrl} alt={`${label} preview`} className="w-full h-full object-cover rounded-md" />
                    <button 
                        onClick={() => onChange(null)} 
                        className="absolute -top-1.5 -right-1.5 bg-white text-black rounded-full p-0.5 hover:bg-gray-300 transition-transform hover:scale-110"
                        aria-label={`Clear ${label}`}
                    >
                        <Icon icon="close" className="w-3 h-3"/>
                    </button>
                </div>
            ) : (
                <button
                    onClick={() => inputRef.current?.click()}
                    disabled={disabled}
                    className="h-9 px-3 bg-slate-700/80 font-semibold text-xs rounded-md hover:bg-slate-600/80 disabled:opacity-50 border border-white/10"
                >
                    Upload
                </button>
            )}
            <input type="file" ref={inputRef} onChange={(e) => onChange(e.target.files ? e.target.files[0] : null)} className="hidden" accept="image/*"/>
        </div>
    );
};


export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({ 
    onUpscale, onRemoveBackground, onApplyStylePreset, onMagicRelight, isLoading, hasOriginalImage,
    quality, setQuality,
    onApplyPose,
    onApplyDepthBlur,
    onExportClick,
    onControlInputChange, controlInputs,
    loadingAction
}) => {
  const isGlobalDisabled = isLoading || !hasOriginalImage;
  const isActionLoading = loadingAction !== null;

  const getButtonDisabled = (action: OneClickAction) => isGlobalDisabled || (isActionLoading && loadingAction !== action);

  return (
    <aside className="w-[320px] flex-shrink-0 h-full flex flex-col gap-4 overflow-y-auto pr-2 pb-2 animate-fadeIn" style={{ animationDelay: '0.3s' }}>
        <PanelCard>
             <div className="grid grid-cols-2 gap-3">
                <ChildButton onClick={onRemoveBackground} disabled={getButtonDisabled('remove-bg')} isLoading={loadingAction === 'remove-bg'}>REMOVE BG</ChildButton>
                <ChildButton onClick={onUpscale} disabled={getButtonDisabled('upscale')} isLoading={loadingAction === 'upscale'}>UPSCALE 2X</ChildButton>
            </div>
        </PanelCard>

        <PanelCard>
            <h3 className="font-bold text-slate-300 mb-3 px-2" style={{ textShadow: 'var(--shadow-text)' }}>AI STYLE PRESETS</h3>
            <div className="grid grid-cols-2 gap-2">
                <ChildButton onClick={() => onApplyStylePreset('cinematic')} disabled={getButtonDisabled('style-cinematic')} isLoading={loadingAction === 'style-cinematic'}>Cinematic</ChildButton>
                <ChildButton onClick={() => onApplyStylePreset('vintage')} disabled={getButtonDisabled('style-vintage')} isLoading={loadingAction === 'style-vintage'}>Vintage</ChildButton>
                <ChildButton onClick={() => onApplyStylePreset('futuristic')} disabled={getButtonDisabled('style-futuristic')} isLoading={loadingAction === 'style-futuristic'}>Futuristic</ChildButton>
                <ChildButton onClick={() => onApplyStylePreset('monochrome')} disabled={getButtonDisabled('style-monochrome')} isLoading={loadingAction === 'style-monochrome'}>Monochrome</ChildButton>
            </div>
        </PanelCard>

        <PanelCard>
            <h3 className="font-bold text-slate-300 mb-3 px-2" style={{ textShadow: 'var(--shadow-text)' }}>MAGIC RELIGHT</h3>
            <div className="grid grid-cols-2 gap-2">
                <ChildButton onClick={() => onMagicRelight('from-left')} disabled={getButtonDisabled('relight-from-left')} isLoading={loadingAction === 'relight-from-left'}>From Left</ChildButton>
                <ChildButton onClick={() => onMagicRelight('from-right')} disabled={getButtonDisabled('relight-from-right')} isLoading={loadingAction === 'relight-from-right'}>From Right</ChildButton>
                <ChildButton onClick={() => onMagicRelight('from-top')} disabled={getButtonDisabled('relight-from-top')} isLoading={loadingAction === 'relight-from-top'}>From Top</ChildButton>
                <ChildButton onClick={() => onMagicRelight('frontal')} disabled={getButtonDisabled('relight-frontal')} isLoading={loadingAction === 'relight-frontal'}>Frontal</ChildButton>
            </div>
        </PanelCard>
        
        <PanelCard>
             <h3 className="font-bold text-slate-300 mb-3 px-2" style={{ textShadow: 'var(--shadow-text)' }}>AI DEPTH BLUR</h3>
            <div className="grid grid-cols-3 gap-2">
                <ChildButton onClick={() => onApplyDepthBlur('subtle')} disabled={getButtonDisabled('blur-subtle')} isLoading={loadingAction === 'blur-subtle'}>Subtle</ChildButton>
                <ChildButton onClick={() => onApplyDepthBlur('medium')} disabled={getButtonDisabled('blur-medium')} isLoading={loadingAction === 'blur-medium'}>Medium</ChildButton>
                <ChildButton onClick={() => onApplyDepthBlur('strong')} disabled={getButtonDisabled('blur-strong')} isLoading={loadingAction === 'blur-strong'}>Strong</ChildButton>
            </div>
        </PanelCard>
        
        <PanelCard>
            <h3 className="font-bold text-slate-300 mb-3 px-2" style={{ textShadow: 'var(--shadow-text)' }}>CONTROL INPUTS</h3>
            <div className="flex flex-col gap-2">
                <ControlInput type="edge" icon="edges" label="Edge Map" data={controlInputs.edge || null} onChange={(file) => onControlInputChange('edge', file)} disabled={isGlobalDisabled || isActionLoading} />
                <ControlInput type="depth" icon="depth" label="Depth Map" data={controlInputs.depth || null} onChange={(file) => onControlInputChange('depth', file)} disabled={isGlobalDisabled || isActionLoading} />
                <ControlInput type="pose" icon="pose" label="Pose Reference" data={controlInputs.pose || null} onChange={(file) => onControlInputChange('pose', file)} disabled={isGlobalDisabled || isActionLoading} />
                <ChildButton onClick={onApplyPose} disabled={getButtonDisabled('pose') || !controlInputs.pose} isLoading={loadingAction === 'pose'}>Apply Pose</ChildButton>
            </div>
        </PanelCard>
        
        <PanelCard>
            <h3 className="font-bold text-slate-300 mb-2 px-2" style={{ textShadow: 'var(--shadow-text)' }}>QUALITY</h3>
            <div className="grid grid-cols-3 gap-1 bg-slate-900/50 p-1 rounded-xl segmented-control">
                {(['low', 'medium', 'high'] as GenerationQuality[]).map(q => (
                     <button
                        key={q}
                        onClick={() => setQuality(q)}
                        disabled={isGlobalDisabled || isActionLoading}
                        className={`w-full h-8 rounded-lg transition-all duration-300 font-semibold text-xs capitalize disabled:opacity-40 disabled:cursor-not-allowed ${quality === q ? 'active' : 'text-slate-300 hover:bg-slate-700/50'}`}
                    >
                     {q}
                    </button>
                ))}
            </div>
        </PanelCard>

        <div className="mt-auto pt-2">
             <button onClick={onExportClick} disabled={!hasOriginalImage} className="w-full h-14 gradient-button font-bold text-lg rounded-2xl">
                EXPORT
             </button>
        </div>
    </aside>
  );
};