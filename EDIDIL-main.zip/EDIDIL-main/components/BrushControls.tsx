import React, { useMemo } from 'react';
import { Icon } from './Icon';
import { Tool } from '../types';

interface BrushControlsProps {
  activeTool: Tool;
  setActiveTool: (tool: Tool) => void;
  brushSize: number;
  setBrushSize: (size: number) => void;
}

export const BrushControls: React.FC<BrushControlsProps> = ({
  activeTool,
  setActiveTool,
  brushSize,
  setBrushSize,
}) => {
  const sliderStyle = useMemo(() => ({
      '--track-fill': `${brushSize}%`,
      '--track-bg': 'linear-gradient(90deg, #ec4899, #f472b6)',
  }), [brushSize]);

  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-900/50 backdrop-blur-lg text-white p-2 rounded-2xl shadow-lg flex items-center gap-4 z-20 border border-white/10">
      <div className="flex items-center gap-1 bg-slate-800/70 p-1 rounded-lg">
        <button
          onClick={() => setActiveTool(Tool.BRUSH)}
          className={`p-2 rounded-md transition-all duration-200 ${activeTool === Tool.BRUSH ? 'bg-pink-600 text-white shadow-md shadow-pink-500/30' : 'hover:bg-slate-700'}`}
          aria-label="Select Brush Tool"
        >
          <Icon icon="brush" className="w-5 h-5" />
        </button>
        <button
          onClick={() => setActiveTool(Tool.ERASER)}
          className={`p-2 rounded-md transition-all duration-200 ${activeTool === Tool.ERASER ? 'bg-pink-600 text-white shadow-md shadow-pink-500/30' : 'hover:bg-slate-700'}`}
          aria-label="Select Eraser Tool"
        >
          <Icon icon="eraser" className="w-5 h-5" />
        </button>
      </div>
      <div className="flex items-center gap-3">
        <label htmlFor="brush-size" className="text-sm font-medium">Size</label>
        <input
          id="brush-size"
          type="range"
          min="1"
          max="100"
          value={brushSize}
          onChange={(e) => setBrushSize(Number(e.target.value))}
          className="w-32 custom-slider"
          // FIX: Cast style object to React.CSSProperties to allow for custom CSS variables.
          style={sliderStyle as React.CSSProperties}
        />
        <span className="text-sm font-mono w-10 text-center bg-slate-700/80 p-1 rounded-md border border-white/10">{brushSize}</span>
      </div>
    </div>
  );
};