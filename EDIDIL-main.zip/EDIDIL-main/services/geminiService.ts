import { GoogleGenAI, Modality } from "@google/genai";
import { AIStylePreset, MagicRelightOption, AIDepthBlurAmount, GenerationQuality } from '../types';

// Ensure API_KEY is available in the environment
if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const fileToGenerativePart = (file: File): Promise<{ inlineData: { data: string; mimeType: string; } }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve({ inlineData: { data: base64, mimeType: file.type } });
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const findImageInResponse = (response: any): string | null => {
    const part = response.candidates?.[0]?.content?.parts?.find(
        (p: any) => p.inlineData && p.inlineData.mimeType.startsWith('image/')
    );
    return part?.inlineData?.data || null;
};


/**
 * Generates an edited image based on a base image and a text prompt.
 * @param base64Image The base64 encoded string of the original image with a transparent mask area.
 * @param mimeType The MIME type of the original image.
 * @param prompt The text prompt guiding the image edit.
 * @param quality The desired generation quality.
 * @param controlImageFiles An array of optional control images (edge, depth, pose maps).
 * @returns A promise that resolves to the base64 encoded string of the generated image.
 */
export async function generateInpaintedImage(
  base64Image: string,
  mimeType: string,
  prompt: string,
  quality: GenerationQuality,
  controlImageFiles: File[] = []
): Promise<string> {
  try {

    const controlImageParts = await Promise.all(controlImageFiles.map(fileToGenerativePart));

    const buildQualityInstructions = (): string => {
        if (quality === 'low') return ' Generation instructions: A low quality, draft, fast generation is acceptable.';
        if (quality === 'high') return ' Generation instructions: Generate a very high-quality, high-detail, and photorealistic result.';
        return '';
    }

    const fullPrompt = `You are an expert photo editor specializing in photorealistic inpainting.
Your task is to fill the transparent area of the provided image based on the user's prompt.
The generated content must seamlessly blend with the surrounding image. Pay close attention to:
- **Lighting and Shadows:** Match the existing light source direction, softness, and color.
- **Texture and Detail:** Replicate the texture and level of detail of the adjacent areas.
- **Color Grading:** Ensure the colors in the filled area are perfectly harmonized with the rest of the image.
- **Perspective:** The generated content must respect the image's perspective.

The final output must be a fully opaque, high-quality, and photorealistic image.
User's instruction: "${prompt}".
${buildQualityInstructions()}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          ...controlImageParts,
          {
            text: fullPrompt,
          },
        ],
      },
      config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    const generatedImage = findImageInResponse(response);
    if (generatedImage) {
        return generatedImage;
    }
    throw new Error("No image was generated in the API response.");
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate image. Please check your API key and network connection.");
  }
}

/**
 * Applies a text prompt to an entire image.
 * @param base64Image The base64 encoded string of the original image.
 * @param mimeType The MIME type of the original image.
 * @param prompt The text prompt guiding the image edit.
 * @param quality The desired generation quality.
 * @returns A promise that resolves to the base64 encoded string of the newly generated image.
 */
export async function generateFullImageEdit(
    base64Image: string,
    mimeType: string,
    prompt: string,
    quality: GenerationQuality
): Promise<string> {
    try {
        const qualityInstruction =
            quality === 'low' ? ' A low quality, fast generation is acceptable.' :
            quality === 'high' ? ' Generate a very high-quality, high-detail, and photorealistic result.' :
            '';

        const fullPrompt = `You are a world-class AI photo editor. Your task is to apply a creative and photorealistic edit to the entire image based on the user's instructions.
Preserve the original subject and composition as much as possible, unless the user explicitly asks to change them.
The final result must be high-quality, believable, and visually stunning.

User's instruction: "${prompt}".
${qualityInstruction}`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    { inlineData: { data: base64Image, mimeType: mimeType } },
                    { text: fullPrompt },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const generatedImage = findImageInResponse(response);
        if (generatedImage) {
            return generatedImage;
        }
        throw new Error("No image was generated in the API response for full image edit.");
    } catch (error) {
        console.error("Error calling Gemini API for full image edit:", error);
        throw new Error("Failed to generate full image edit. Please check your API key and network connection.");
    }
}


/**
 * Upscales an image to 2x its resolution using the Gemini API.
 * @param base64Image The base64 encoded string of the image to upscale.
 * @param mimeType The MIME type of the image.
 * @returns A promise that resolves to the base64 encoded string of the upscaled image.
 */
export async function upscaleImage(base64Image: string, mimeType: string): Promise<string> {
    try {
        const prompt = "Upscale this image to twice its original resolution. Enhance details, sharpness, and clarity. Do not add, remove, or change any content in the image. The output must be a high-fidelity, photorealistic upscaled version of the provided image.";
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const upscaledImage = findImageInResponse(response);
        if (upscaledImage) {
            return upscaledImage;
        }
        throw new Error("No upscaled image was generated in the API response.");
    } catch (error) {
        console.error("Error calling Gemini API for upscaling:", error);
        throw new Error("Failed to upscale image. Please try again later.");
    }
}

/**
 * Removes the background from an image using the Gemini API.
 * @param base64Image The base64 encoded string of the image.
 * @param mimeType The MIME type of the image.
 * @returns A promise that resolves to the base64 encoded string of the image with the background removed.
 */
export async function removeBackground(base64Image: string, mimeType: string): Promise<string> {
    try {
        const prompt = "Remove the background from this image. The subject should be perfectly isolated with clean, precise edges, especially around hair or fine details. The background must be fully transparent. The output must be a PNG image with an alpha channel.";
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const resultImage = findImageInResponse(response);
        if (resultImage) {
            return resultImage;
        }
        throw new Error("No image was returned from the background removal process.");
    } catch (error) {
        console.error("Error calling Gemini API for background removal:", error);
        throw new Error("Failed to remove background. Please try again later.");
    }
}

/**
 * Applies a full-image style preset using the Gemini API.
 * @param base64Image The base64 encoded string of the image.
 * @param mimeType The MIME type of the image.
 * @param style The style preset to apply.
 * @returns A promise that resolves to the base64 encoded string of the styled image.
 */
export async function applyStylePreset(base64Image: string, mimeType: string, style: AIStylePreset): Promise<string> {
    let prompt = '';
    switch (style) {
        case 'cinematic':
            prompt = "Apply a cinematic style to this entire image. Enhance the colors with a teal and orange color grade, increase the contrast for dramatic lighting, and add a slight vignette. The result should look like a still from a high-budget film.";
            break;
        case 'vintage':
            prompt = "Apply a vintage photo style to this entire image. Give it a warm, faded color tone, slightly reduced contrast, and add a light, realistic film grain. The colors should feel reminiscent of old film photography from the 1970s. The result should look authentic.";
            break;
        case 'futuristic':
            prompt = "Apply a futuristic, cyberpunk style to this entire image. Introduce neon glows, especially in highlights. Shift the color palette towards blues, purples, and magentas. Increase the sharpness and clarity. The result should feel high-tech, sleek, and a bit dystopian.";
            break;
        case 'monochrome':
            prompt = "Convert this entire image to a high-contrast, dramatic black and white style. Preserve deep blacks and bright whites. The tonal range should be wide and the result should be a powerful monochrome photograph.";
            break;
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const resultImage = findImageInResponse(response);
        if (resultImage) {
            return resultImage;
        }
        throw new Error(`No image was returned from the ${style} style preset process.`);
    } catch (error) {
        console.error(`Error calling Gemini API for ${style} preset:`, error);
        throw new Error(`Failed to apply ${style} preset. Please try again later.`);
    }
}

/**
 * Applies realistic relighting to an image from a specified direction.
 * @param base64Image The base64 encoded string of the image.
 * @param mimeType The MIME type of the image.
 * @param direction The direction for the new primary light source.
 * @returns A promise that resolves to the base64 encoded string of the relit image.
 */
export async function magicRelight(base64Image: string, mimeType: string, direction: MagicRelightOption): Promise<string> {
    let prompt = `Realistically relight this image. The primary light source should now come from a new direction. All highlights and shadows must be redrawn to match this new light source. Preserve the original content, textures, and colors of the image. The result should be photorealistic and believable. The new primary light source is coming from: `;

    switch (direction) {
        case 'from-left':
            prompt += 'the left side of the frame.';
            break;
        case 'from-right':
            prompt += 'the right side of the frame.';
            break;
        case 'from-top':
            prompt += 'above the subject.';
            break;
        case 'frontal':
            prompt += 'the front, slightly above the camera (like a soft ring light).';
            break;
    }
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const resultImage = findImageInResponse(response);
        if (resultImage) {
            return resultImage;
        }
        throw new Error(`No image was returned from the magic relight process.`);
    } catch (error) {
        console.error(`Error calling Gemini API for magic relight:`, error);
        throw new Error(`Failed to apply magic relight. Please try again later.`);
    }
}

/**
 * Applies a pose from a reference image to a subject in the main image.
 * @param base64Image The base64 encoded string of the main image.
 * @param mimeType The MIME type of the main image.
 * @param poseReferenceFile The pose reference image file.
 * @returns A promise that resolves to the base64 encoded string of the image with the new pose.
 */
export async function applyPoseTransfer(base64Image: string, mimeType: string, poseReferenceFile: File): Promise<string> {
    try {
        const poseReferencePart = await fileToGenerativePart(poseReferenceFile);

        const prompt = `Transfer the pose from the second image (pose reference) to the main subject in the first image (main image). It is critical that you preserve the subject's identity, face, clothing, and appearance from the main image. The background, lighting, and overall style of the main image must also be preserved. The output should be a photorealistic image of the original subject in the new pose, seamlessly blended into the original background.`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    poseReferencePart,
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const resultImage = findImageInResponse(response);
        if (resultImage) {
            return resultImage;
        }
        throw new Error("No image was returned from the pose transfer process.");
    } catch (error) {
        console.error("Error calling Gemini API for pose transfer:", error);
        throw new Error("Failed to apply pose transfer. Please try again later.");
    }
}

/**
 * Applies a realistic depth-of-field blur to an image.
 * @param base64Image The base64 encoded string of the image.
 * @param mimeType The MIME type of the image.
 * @param amount The intensity of the blur.
 * @returns A promise that resolves to the base64 encoded string of the blurred image.
 */
export async function applyDepthBlur(base64Image: string, mimeType: string, amount: AIDepthBlurAmount): Promise<string> {
    let prompt = `You are a professional photo editor. Your task is to apply a realistic, photographic depth-of-field (bokeh) effect to this image.
    1. Intelligently identify the primary subject(s) of the photo.
    2. Keep the primary subject(s) perfectly sharp and in focus.
    3. Realistically blur the background to simulate a shallow depth of field from a professional DSLR camera with a wide aperture lens.
    4. The transition between the in-focus subject and the blurred background must be seamless and natural, with accurate edge detection.
    The desired intensity of the background blur is: ${amount}.
    The output must be a high-quality, photorealistic image.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Image,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const resultImage = findImageInResponse(response);
        if (resultImage) {
            return resultImage;
        }
        throw new Error(`No image was returned from the AI Depth Blur process.`);
    } catch (error) {
        console.error(`Error calling Gemini API for AI Depth Blur:`, error);
        throw new Error(`Failed to apply AI Depth Blur. Please try again later.`);
    }
}